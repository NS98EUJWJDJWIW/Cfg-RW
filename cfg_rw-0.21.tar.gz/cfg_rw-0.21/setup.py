import setuptools
setuptools.setup(
    name='cfg_rw',
    version='0.21',
    author='Nos',
    author_email='1047743353@qq.com',
    description='An easily config reader/writer',
    long_description='Config-Read-Write',
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ]
)